package com.dvdiscanner.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    private val askNotifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel(this)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { SignalScreen() } }
    }
}

data class Kline(val open: Double, val high: Double, val low: Double, val close: Double, val volume: Double, val closeTime: Long)
data class ScanResult(val price: Double, val indicator: Double, val rising: Boolean, val signal: String?, val lastSignal: String?, val lastSignalTime: Long?, val candleClose: Long, val bars:Int)
data class Trade(val side:String, val entry:Double, val exit:Double, val entryTime:Long, val exitTime:Long, val returnPct:Double, val maxFavorablePct:Double)
data class BacktestRow(val allocation:Int, val trades:Int, val wins:Int, val losses:Int, val net:Double, val ending:Double, val maxDrawdown:Double)
data class BacktestResult(val rows:List<BacktestRow>, val tpHits:IntArray, val trades:Int, val firstTime:Long, val lastTime:Long)
data class UiState(val loading: Boolean = true, val result: ScanResult? = null, val backtest:BacktestResult?=null, val error: String? = null)

class SignalViewModel : ViewModel() {
    var state by mutableStateOf(UiState()); private set
    private val client = OkHttpClient()
    init { refresh() }

    fun refresh() = viewModelScope.launch {
        state = state.copy(loading = true, error = null)
        try {
            val pair = withContext(Dispatchers.IO) { val bars=loadBars(); Pair(scan(bars), backtest(bars)) }
            state = UiState(false, pair.first, pair.second)
        } catch (e: Exception) { state = UiState(false, error = e.message ?: "Unknown error") }
    }

    private fun loadBars():List<Kline> {
        val url = "https://fapi.binance.com/fapi/v1/klines?symbol=BTCUSDC&interval=4h&limit=1400"
        val body = client.newCall(Request.Builder().url(url).build()).execute().use { r ->
            if (!r.isSuccessful) error("Futures market data error ${r.code}")
            r.body?.string() ?: error("Empty market data response")
        }
        val a=JSONArray(body); val now=System.currentTimeMillis(); val bars=mutableListOf<Kline>()
        for(i in 0 until a.length()) { val k=a.getJSONArray(i); val ct=k.getLong(6); if(ct<now) bars += Kline(k.getString(1).toDouble(),k.getString(2).toDouble(),k.getString(3).toDouble(),k.getString(4).toDouble(),k.getString(5).toDouble(),ct) }
        require(bars.size>=300){"Not enough completed 4H history"}; return bars
    }

    private fun scan(bars:List<Kline>):ScanResult {
        val values=IndicatorEngine.calculate(bars,255,1); val n=values.lastIndex; val rising=values[n]>values[n-1]
        val current=when { rising && values[n-1]<=values[n-2] -> "BUY"; !rising && values[n]<values[n-1] && values[n-1]>=values[n-2] -> "SELL"; else -> null }
        var latest:String?=null; var latestTime:Long?=null
        for(i in n downTo 2){ val up=values[i]>values[i-1]&&values[i-1]<=values[i-2]; val down=values[i]<values[i-1]&&values[i-1]>=values[i-2]; if(up||down){latest=if(up)"BUY" else "SELL";latestTime=bars[i].closeTime;break}}
        return ScanResult(bars.last().close,values[n],rising,current,latest,latestTime,bars.last().closeTime,bars.size)
    }

    private fun backtest(bars:List<Kline>):BacktestResult {
        val v=IndicatorEngine.calculate(bars,255,1); val signals=mutableListOf<Pair<Int,String>>()
        // First 255 bars are warm-up only; trades start after that.
        for(i in 256..v.lastIndex){ val up=v[i]>v[i-1]&&v[i-1]<=v[i-2]; val down=v[i]<v[i-1]&&v[i-1]>=v[i-2]; if(up||down) signals += i to if(up)"LONG" else "SHORT" }
        val trades=mutableListOf<Trade>()
        for(s in 0 until signals.size-1){
            val (ei,side)=signals[s]; val xi=signals[s+1].first
            val entry=bars[ei].close; val exit=bars[xi].close
            var mfe=0.0
            for(j in ei+1..xi){ val fav=if(side=="LONG") (bars[j].high/entry-1.0)*100.0 else (1.0-bars[j].low/entry)*100.0; if(fav>mfe)mfe=fav }
            val raw=if(side=="LONG") (exit/entry-1.0)*100.0 else (1.0-exit/entry)*100.0
            trades += Trade(side,entry,exit,bars[ei].closeTime,bars[xi].closeTime,raw,mfe)
        }
        val tp=doubleArrayOf(.4,.9,2.0,6.0,10.0); val hits=IntArray(tp.size){k->trades.count{it.maxFavorablePct>=tp[k]}}
        val rows=(1..6).map { alloc ->
            var bal=1000.0; var peak=bal; var maxDd=0.0; var wins=0; var losses=0
            for(t in trades){
                val exposure=bal*(alloc/100.0)*10.0
                val gross=exposure*(t.returnPct/100.0)
                val fees=exposure*0.0004*2.0 // baseline: taker fee at entry + exit; funding excluded
                val pnl=gross-fees; bal+=pnl
                if(pnl>=0)wins++ else losses++
                if(bal>peak)peak=bal
                val dd=if(peak>0)(peak-bal)/peak*100.0 else 0.0; if(dd>maxDd)maxDd=dd
            }
            BacktestRow(alloc,trades.size,wins,losses,bal-1000.0,bal,maxDd)
        }
        val first=if(trades.isNotEmpty())trades.first().entryTime else bars.first().closeTime; val last=if(trades.isNotEmpty())trades.last().exitTime else bars.last().closeTime
        return BacktestResult(rows,hits,trades.size,first,last)
    }
}

object IndicatorEngine {
    fun calculate(bars: List<Kline>, period: Int, smooth: Int): DoubleArray {
        val n=bars.size; val p=DoubleArray(n); val nv=DoubleArray(n)
        if(n>0 && bars[0].volume>0.0) p[0]=bars[0].close
        for(i in 1 until n){ val d=bars[i].close-bars[i-1].close; p[i]=if(bars[i].volume>bars[i-1].volume)p[i-1]+d else p[i-1]; nv[i]=if(bars[i].volume<bars[i-1].volume)nv[i-1]-d else nv[i-1] }
        val ps=ema(p,period); val ns=ema(nv,period); val pd=ema(DoubleArray(n){p[it]-ps[it]},smooth); val nd=ema(DoubleArray(n){nv[it]-ns[it]},smooth)
        return DoubleArray(n){pd[it]-nd[it]}
    }
    private fun ema(x:DoubleArray,length:Int):DoubleArray{ val out=DoubleArray(x.size);if(x.isEmpty())return out;val a=2.0/(length+1.0);out[0]=x[0];for(i in 1 until x.size)out[i]=out[i-1]+a*(x[i]-out[i-1]);return out }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun SignalScreen(vm:SignalViewModel=viewModel()){
    val s=vm.state;val r=s.result;val bt=s.backtest
    Scaffold(topBar={TopAppBar(title={Text("BTC/USDC Signal")})}){pad->
        Column(Modifier.padding(pad).padding(18.dp).fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(14.dp)){
            Text("BTC/USDC PERPETUAL • 4H",style=MaterialTheme.typography.titleLarge)
            Text("Signal + 1,400 candle backtest • no order execution")
            Button(onClick=vm::refresh,enabled=!s.loading){Text(if(s.loading)"Loading…" else "Refresh signal & backtest")}
            s.error?.let{Text(it,color=MaterialTheme.colorScheme.error)}
            r?.let{ ElevatedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
                Text("Price     ${money(it.price)}",style=MaterialTheme.typography.headlineSmall);Text("Indicator     ${if(it.rising)"▲ RISING" else "▼ FALLING"}");Text("Signal     ${it.signal?:"—"}");Text("Last confirmed     ${it.lastSignal?:"—"}");it.lastSignalTime?.let{t->Text("Signal candle     ${time(t)}")};Text("4H candle closed     ${time(it.candleClose)}");Text("Completed candles loaded: ${it.bars}")
            }}}
            bt?.let{ ElevatedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
                Text("Backtest — €1,000 / 10×",style=MaterialTheme.typography.titleMedium);Text("Trade window: ${date(it.firstTime)} → ${date(it.lastTime)}");Text("Confirmed reversal trades: ${it.trades}");Text("Exit: next opposite confirmed reversal");Text("Baseline fee: 0.04% each side • funding excluded",style=MaterialTheme.typography.bodySmall)
                HorizontalDivider();Text("Allocation     Net P/L     End balance     Max DD")
                it.rows.forEach{row->Text("${row.allocation}%          ${signedEuro(row.net)}     ${euro(row.ending)}     ${"%.1f".format(row.maxDrawdown)}%")}
                HorizontalDivider();Text("Target reach before reversal",style=MaterialTheme.typography.titleSmall);val labels=listOf("TP1 +0.4%","TP2 +0.9%","TP3 +2%","TP4 +6%","TP5 +10%");labels.forEachIndexed{i,l->Text("$l     ${it.tpHits[i]} / ${it.trades}")}
            }}}
            ElevatedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Text("Paper bot",style=MaterialTheme.typography.titleMedium);Text("Trading: OFF");Text("This build measures the signal first. TP hits are statistics, not partial exits.")}}
            Spacer(Modifier.height(20.dp))
        }
    }
}

private fun money(x:Double)="$"+"%,.2f".format(x)
private fun euro(x:Double)="€"+"%,.2f".format(x)
private fun signedEuro(x:Double)=(if(x>=0)"+" else "-")+euro(kotlin.math.abs(x))
private fun time(ms:Long)=DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm z").withZone(ZoneId.systemDefault()).format(Instant.ofEpochMilli(ms))
private fun date(ms:Long)=DateTimeFormatter.ofPattern("yyyy-MM-dd").withZone(ZoneId.systemDefault()).format(Instant.ofEpochMilli(ms))
private fun createNotificationChannel(c:Context){if(Build.VERSION.SDK_INT>=26){val nm=c.getSystemService(NotificationManager::class.java);nm.createNotificationChannel(NotificationChannel("signals","Trade signals",NotificationManager.IMPORTANCE_HIGH))}}
