# BTC/USDC Signal Android V0.3.1

Validation build. No real or paper orders are executed.

## What it does
- BTC/USDC USDⓈ-M perpetual futures only
- 4H completed candles
- Downloads up to 1,400 candles from Binance Futures
- Uses first 255 bars as warm-up
- BUY/SELL on confirmed Indicator direction reversal
- Backtests each completed reversal trade, exiting on the next opposite reversal
- Compares a €1,000 account at 1%, 2%, 3%, 4%, 5%, 6% margin allocation with 10x notional exposure
- Baseline assumes 0.04% taker fee on entry and exit; funding/slippage/liquidation are not included yet
- TP 0.4%, 0.9%, 2%, 6%, 10% are reported as target-reach statistics only; they do not partially close positions in this validation build

## Build APK
Open this folder in Android Studio, allow Gradle sync, then Build > Build App Bundle(s) / APK(s) > Build APK(s).
The debug APK will normally be at app/build/outputs/apk/debug/app-debug.apk.


## V0.3.1 baseline
This repository-ready build preserves the uploaded V0.3 signal and backtest logic unchanged. Only Android version metadata and GitHub housekeeping were added.
